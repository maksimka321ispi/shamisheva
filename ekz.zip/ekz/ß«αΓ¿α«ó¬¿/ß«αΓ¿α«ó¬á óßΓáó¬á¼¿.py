from random import randint
def insertion_sort(arr):
    for i in range(1, len(arr)):
        key = arr[i]
        j = i - 1
        while j >= 0 and arr[j] > key:
            arr[j + 1] = arr[j]
            j -= 1
        arr[j + 1] = key
    return arr

arr = [randint(-10, 10) for i in range(10)]
print(arr)
print(insertion_sort(arr))

# делит список на уже отсортированную и несортированную части, до 1 итераци только 1 эл-нт относится к отсортированной
# с каждой итерацией отсортированная часть расширяется, т.е сравнивается 1 эл-нт из неотсортироавнной части со всеми
# эл-ми отсортированной части и меняет их местами

# сложность O(n^2)