from random import randint
def selection_sort(arr):
    n = len(arr)
    for i in range(n - 1):
        min_index = i
        for j in range(i + 1, n):
            if arr[j] < arr[min_index]:
                min_index = j
        arr[i], arr[min_index] = arr[min_index], arr[i]
    return arr

arr = [randint(-10, 10) for i in range(10)]
print(arr)
print(selection_sort(arr))

# сначала i = минимальный элемент, индекс j перебирает все эл-ты массива и выбирает минимальный эл-т, приравнивает j к
# минимальному эле-ту и меняет местами i с минимальным эл-ом

# сложность O(n^2)