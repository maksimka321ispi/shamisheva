from random import randint
def bubble_sort(arr):
    n = len(arr)
    for i in range(n - 1):
        for j in range(n - 1 - i):
            if arr[j] > arr[j + 1]:
                arr[j], arr[j + 1] = arr[j + 1], arr[j]
    return arr

arr = [randint(-10, 10) for i in range(10)]
print(arr)
print(bubble_sort(arr))

# сравниваем 2 парных элемента списка, если правый элемент меньше, то меняем его местами с левым

# сложность 0(N^2)