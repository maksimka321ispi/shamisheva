from random import randint
# с рекурсией
def quicksort(nums, fst, lst):
    i, j = fst, lst
    pivot = nums[randint(fst, lst)]
    while i <= j:
        while nums[i] < pivot:
            i += 1
        while nums[j] > pivot:
            j -= 1
        if i <= j:
            nums[i], nums[j] = nums[j], nums[i]
            i, j = i + 1, j - 1
    if fst < j:
        quicksort(nums, fst, j)
    if i < lst:
        quicksort(nums, i, lst)
    return nums

# chat-gpt
def quicksort_2(arr):
    if len(arr) <= 1:
        return arr
    else:
        pivot = arr[0]
        less = [x for x in arr[1:] if x <= pivot]
        greater = [x for x in arr[1:] if x > pivot]
        return quicksort(less) + [pivot] + quicksort(greater)

# без рекурсии
def quick_sort(nums_2, fst, lst):
    if len(nums_2) <= 1:
        return nums_2
    stack = [(0, len(nums_2) - 1)]
    # пока стек не пуст
    while stack:
        fst, lst = stack.pop()
        i, j = fst, lst
        pivot = nums_2[randint(fst, lst)]
        while i <= j:
            while nums_2[i] < pivot:
                i += 1
            while nums_2[j] > pivot:
                j -= 1
            if i <= j:
                nums_2[i], nums_2[j] = nums_2[j], nums_2[i]
                i, j = i + 1, j - 1
        if fst < j:
            stack.append((fst, j))
        if i < lst:
            stack.append((i, lst))
    return nums_2

nums = [randint(-100, 100) for i in range(10)]
print(quicksort(nums, 0, len(nums) - 1))
