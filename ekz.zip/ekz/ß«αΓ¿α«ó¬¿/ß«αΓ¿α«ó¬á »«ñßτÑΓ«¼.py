from random import randint
def counting_sort(arr):
    n = len(arr)
    min_val = arr[0]
    max_val = arr[0]
    for i in range(1, n):
        if arr[i] < min_val:
            min_val = arr[i]
        if arr[i] > max_val:
            max_val = arr[i]
    m = max_val - min_val + 1

    x = [0] * m
    for i in arr:
        x[i - min_val] += 1

    j = 0
    for i in range(m):
        while x[i] != 0:
            arr[j] = i + min_val
            j += 1
            x[i] -= 1
    return arr

arr = [randint(-10, 10) for i in range(10)]
print(arr)
print(counting_sort(arr))

#чтобы сделать по убыванию: j = -1 и j -= 1

# сложность O(n+k)