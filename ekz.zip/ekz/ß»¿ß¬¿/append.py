class Node:
    def __init__(self):
        self.head: Node
        self.tail: Node

def append(self, value: int):
    node = Node(value)
    if not self.head:
        self.head = self.tail = node
        return
    self.tail.next = node
    self.tail = node
