class Node:
    def __init__(self):
        self.head: Node
        self.tail: Node

def push(self, value: int):
    if not self.head:
        self.head = self.tail = Node(value)
        return
    node = Node(value)
    node.next = self.head
    self.head = node
