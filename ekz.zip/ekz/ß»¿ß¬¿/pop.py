def pop(self):
    if not self.head:
        return None
    value = self.head.data
    if self.head == self.tail:
        self.head = self.tail = None
        return value
    self.head = self.head.next
    return value
