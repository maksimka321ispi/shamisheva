class Node:
    def __init__(self):
        self.head: Node
        self.tail: Node

def delete_node(self, node: Node, pred: Node):
    if node is not None and pred is not None:
        if node.right is not None and node.left is not None:
            node.data = self._pop_max(node.left, node)
        else:
            if node.left is not None:
                if pred.left is node:
                    pred.left = node.left

                else:
                    pred.right = node.left

            else:
                if pred.left is node:
                    pred.left = node.right
                else:
                    pred.right = node.right

            del node
