def perevod(n):
        if n == 0:
            return '0'
        binary = ''
        while n > 0:
            binary = str(n % 2) + binary
            n //= 2
        return binary

def perevod_recursion(n):
    if n == 0:
        return '0'
    elif n == 1:
        return '1'
    else:
        return perevod_recursion(n // 2) + str(n % 2)

print(perevod(100))
print(perevod_recursion(100))