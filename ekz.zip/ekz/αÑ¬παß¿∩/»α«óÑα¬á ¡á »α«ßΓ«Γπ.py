def prostoe(n, j):
    if n <= 1:
        return False
    if n == j:
        return True
    if n % j == 0:
        return False
    return prostoe(n, j + 1)
n = int(input("Введите число: "))
print(prostoe(n, 2))