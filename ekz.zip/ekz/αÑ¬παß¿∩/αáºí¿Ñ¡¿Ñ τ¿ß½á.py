def find(m, n=1):
    if m == 0:
        return 1
    if n > m:
        return 0
    return find(m-n, n) + find(m, n+1)

m = int(input("Введите натуральное число: "))
print(find(m))
