def fib(n):
    if n <= 0:
        return 0
    elif n == 1:
        return 1
    else:
        return fib(n - 1) + fib(n - 2)

def fib_cash(n):
    if n not in cash:
        cash[n] = fib_cash(n-1) + fib_cash(n - 2)
    return cash[n]

cash = {0: 1, 1: 1}
print(fib_cash(900))