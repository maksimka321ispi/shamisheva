def euclidean(a, b):
    while b != 0:
        remainder = a % b
        a = b
        b = remainder
    return a

def euclidean_recursive(a, b):
    if b == 0:
        return a
    else:
        return euclidean_recursive(b, a % b)

a = int(input("Введите число a: "))
b = int(input("Введите чилсло b: "))
print(f"НОД чисел {a} и {b} = {euclidean_recursive(a, b)}")