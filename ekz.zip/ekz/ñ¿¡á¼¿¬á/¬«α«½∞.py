def find_optimal_path(Price):
    N = len(Price)
    optimal_cost = [[0 for j in range(N)] for i in range(N)]
    optimal_cost[0][0] = Price[0][0]

    for i in range(1, N):
        optimal_cost[i][0] = Price[i][0] + optimal_cost[i - 1][0]
        optimal_cost[0][i] = Price[0][i] + optimal_cost[0][i - 1]

    for i in range(1, N):
        for j in range(1, N):
            optimal_cost[i][j] = Price[i][j] + min(optimal_cost[i - 1][j], optimal_cost[i][j - 1], optimal_cost[i - 1][j - 1])

    path = []
    i, j = N - 1, N - 1
    while i > 0 or j > 0:
        path.append((i, j))
        if i == 0:
            j -= 1
        elif j == 0:
            i -= 1
        else:
            if optimal_cost[i - 1][j] < optimal_cost[i][j - 1] and optimal_cost[i - 1][j] < optimal_cost[i - 1][j - 1]:
                i -= 1
            elif optimal_cost[i][j - 1] < optimal_cost[i - 1][j] and optimal_cost[i][j - 1] < optimal_cost[i - 1][j - 1]:
                j -= 1
            else:
                i -= 1
                j -= 1
    path.append((0, 0))
    path = path[::-1]

    return optimal_cost[N - 1][N - 1], path

Price = [[6, 1, 4, 5, 7],
        [0, 4, 3, 8, 0],
        [1, 0, 4, 1, 8],
        [8, 5, 3, 0, 4],
        [4, 5, 1, 2, 3]]

optimal_cost, optimal_path = find_optimal_path(Price)

print("Минимальная стоимость пути:", optimal_cost)
print("Оптимальный путь:", optimal_path)
