def ladder(n, cost):
    dp = [0] * n
    dp[0] = cost[0]
    dp[1] = cost[1]

    for i in range(2, n):
        dp[i] = dp[i - 1]
        if dp[i - 2] < dp[i - 1]:
            dp[i] = dp[i - 2]
        dp[i] += cost[i]

    return dp[-1] if dp[-1] < dp[-2] else dp[-2]

cost = [1, 2, 3, 5, 1, 4]
n = len(cost)
print("Наименьшая стоимость прохода по лесенке:", ladder(n, cost))
