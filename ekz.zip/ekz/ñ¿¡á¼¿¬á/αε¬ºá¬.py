def knapsack(weights, prices, x):
    n = len(weights)
    dp = [[0] * (x + 1) for i in range(n + 1)]

    for i in range(1, n + 1):
        for j in range(x, weights[i - 1] - 1, -1):
            if weights[i - 1] <= j:
                dp[i][j] = dp[i - 1][j - weights[i - 1]] + prices[i - 1]
                if dp[i][j] < dp[i - 1][j]:
                    dp[i][j] = dp[i - 1][j]
            else:
                dp[i][j] = dp[i - 1][j]
    return dp[n][x]


weights = [1, 10, 1, 1, 2, 2, 1, 2, 1, 1, 2, 5, 2]
prices = [10, 10, 1, 10, 7, 2, 8, 8, 9, 7, 1, 2, 1]
x = int(input("Введите вместимость: "))
print("Максимальная стоимость рюкзака:", knapsack(weights, prices, x))