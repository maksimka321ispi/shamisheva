from random import randint
def linear_search(nums, n):
    for i in range(len(nums)):
        if nums[i] == n:
            return i
    return None

nums = [randint(-100, 100) for i in range(10)]
print(nums)
n = int(input("Введите число для поиска: "))
print(f"Число {n} находится на позиции: {linear_search(nums, n)}")