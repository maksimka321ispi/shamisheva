from random import randint
def bubble_sort(arr):
    n = len(arr)
    for i in range(n - 1):
        for j in range(n - 1 - i):
            if arr[j] > arr[j + 1]:
                arr[j], arr[j + 1] = arr[j + 1], arr[j]
    return arr

def binary_search_recursion(nums_2, low, high, n2):
    if low <= high:
        mid = (low + high) // 2
        if nums_2[mid] == n2:
            return mid
        elif nums_2[mid] > n2:
            return binary_search_recursion(nums_2, low, mid - 1, n2)
        else:
            return binary_search_recursion(nums_2, mid + 1, high, n2)

def binary_search(nums, n):
    low, high = 0, len(nums) - 1
    while low <= high:
        # Определение середины
        mid = (low + high) // 2
        if nums[mid] < n:
            low = mid + 1
        elif nums[mid] > n:
            high = mid - 1
        else:
            return mid

nums = [randint(-10, 10) for i in range(10)]
print("Неотсортированный массив:", nums)
print("Отсортированный массив:", bubble_sort(nums))
n = int(input("Введите индекс какого числа из отсортированного массива вы хотите найти: "))
print(f"Индекс числа {n} = {binary_search(nums, n)}")
print(f"Индекс числа {n} = {binary_search_recursion(nums, 0, len(nums) - 1, n)}")